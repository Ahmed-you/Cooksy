export const cooksyTypingIndicator = `
 <div class="msg-row cooksy cooksyType">
  <img src="./imgs/cooksy.png" class="cooksy-chat-icon">

  <div class="cooksy-bubble">
   <b style="font-weight:700;">. . .<b>
  </div>
 </div>
`;
