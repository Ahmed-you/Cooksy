export const userBubble = `<div class="msg-row user">
<div class="user-bubble">{{Msg}}</div>
</div>
`;
