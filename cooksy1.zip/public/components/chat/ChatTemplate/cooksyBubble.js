export const cooksyBubble = `
 <div class="msg-row cooksy">
  <img src="./imgs/cooksy.png" class="cooksy-chat-icon">

  <div class="cooksy-bubble">
   {{Msg}}
  </div>
 </div>
`;
