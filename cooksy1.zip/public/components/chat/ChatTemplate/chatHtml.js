export const chatBox = `<div class="chatBox">
 
</div>
`;

//  <div class="msg-row user">
//     <div class="user-bubble">{{userMsg}}</div>
//   </div>
