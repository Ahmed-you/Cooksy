export const recipeGridView = `<div class="recipeGridView-container">
</div>`;

export const recipeItem = `<div class="recipe-item-container" id = "{{recipeId}}">
        <img src="{{imgUrl}}" alt="Image is missing" class="recipe-thumbnail">
        <div class="recipe-title">{{recipeTitle}}</div>
    </div>
    `;
